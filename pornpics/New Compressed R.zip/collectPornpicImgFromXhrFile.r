# collect Pornpic Img From Xhr File
rm(list = ls())
Sys.setlocale(category = 'LC_ALL', 'Chinese')
setwd("C:/Users/User/Pictures/sexpage")
library(rvest)
library(crayon)
 ligSilver <- make_style("#889988")

pageHeader="https://www.pornpics.com/galleries/"
pageTail=""
className = ".thumbwook a" # pornpic
schkeyHistory = readLines("pornpicHistory.txt")
#xhrFileName = readline(prompt="Enter xhr file name without .txt: ")
xhrFileName = "Bikini.txt"
xhr = readLines(xhrFileName)

dhms <- function(t){
    paste(t %/% (60*60*24), "day" 
         ,paste(formatC(t %/% (60*60) %% 24, width = 2, format = "d", flag = "0")
               ,formatC(t %/% 60 %% 60, width = 2, format = "d", flag = "0")
               ,formatC(t %% 60, width = 2, format = "d", flag = "0")
               ,sep = ":"
               )
         )
}

  retrieveFile <- function(urlAddr){
    retryCounter = 1
    while(retryCounter < 5) {
      cat("...try ",retryCounter, "\n") 
      retriveFile <- tryCatch(read_html(urlAddr, warn=F, encoding = "UTF-8"), 
                        warning = function(w){
                         cat(silver("code param error "));
                         return(" code param error ")
                        }, 
                        error = function(e) {
                          if(grepl("Error in open.connection", e)){
                            cat(silver(" Error in open.connection "))
                            return("Error in open.connection")
                          }else if(grepl("Error in doc_parse_raw", e)){
                            cat(silver(" Error in doc_parse_raw, "))
                            return(read_html(urlAddr, warn=F))
                          }else{
                            cat(red(" unknown error "))
                            return("unknown error")
                          }
                        }
                     )
      if (grepl("code param error", retriveFile)) {
        cat(red(" Error in connection, try 5 secs later!\n"))
        retryCounter <- retryCounter + 1
        retriveFile = "<html></html>"  # if end of loop this will be returned
        retryCounter = 200  # to jump out of loop
      }else if(grepl("Error in open.connection", retriveFile)){
        cat(red("unable to connect! \n"), urlAddr,"\n")
        retryCounter <- retryCounter + 1
        retriveFile = "<html></html>"  # if end of loop this will be returned
        retryCounter = 200  # to jump out of loop
      }else if(grepl("unknown error", retriveFile)){
        retriveFile = "<html></html>"  # if end of loop this will be returned
        retryCounter = 200  # to jump out of loop
      }else{
        #cat(green(" \tseems OK! "))
        retryCounter = 200  # to jump out of loop
      }
    }
    #cat(green(" loop end retry counts: ", retryCounter, "\n"))
    return(retriveFile)
  }


# main loop
  wholePage = character()
  xhrlen = length(xhr)
  ProcessStartTime = Sys.time()
  if(xhrlen>3000){
    cat(red("\nlist too long! chop into sections!\n"))
    longxhr = xhr

    for
  }

  for(i in 1:xhrlen){
    url = paste0(pageHeader,xhr[i],pageTail)
    cat(yellow(i, "of",xhrlen, url))
    pagesource <- retrieveFile(url)
  
    itemList <- html_nodes(pagesource, className)
  
    itemList = html_attr(itemList, 'href')
    itemList = as.character(itemList)
    itemList = gsub('https://cdni.pornpics.com/1280/', '\'', itemList)
    itemList = gsub('\\.jpg', '\',', itemList)
  
    wholePage = c(wholePage, itemList)
  
    if(i == 10){
      ProcessEndTime = Sys.time()
      LoopTime = as.numeric(ProcessEndTime - ProcessStartTime, units="secs")
      ecTime = xhrlen*LoopTime/10
  
      cat(red(
          "\n\n Expect to complete at: ", as.character(ProcessStartTime + ecTime),"\n",
          "per cycle time: ", dhms(LoopTime/10),"\n",
          "Expected total time: ", dhms(ecTime),"\n\n"
         ))
    }
  }


  templateHead = readLines("templateHeadArray.txt")
  templateTail = readLines("templateTailArray.txt")
  templateHead = gsub("penny-barber", titleName, templateHead)
  templateTail = gsub("penny-barber", titleName, templateTail)
  
  theFilename = paste0("pornpics", titleName, ".html")
  sink(theFilename)
  cat(templateHead, sep="\n")
  cat(wholePage, sep="\n")
  cat(templateTail, sep="\n")
  sink()
